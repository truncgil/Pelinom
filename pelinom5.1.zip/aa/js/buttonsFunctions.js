/* BUTTONS EFFECT */
/*
Waves.attach('.float-dark', ['waves-button', 'waves-dark']);
Waves.attach('.float-button', ['waves-button', 'waves-light']);
Waves.attach('.float-button-light', ['waves-button', 'waves-float', 'waves-light']);
Waves.attach('.float-button-dark', ['waves-button', 'waves-float', 'waves-dark']);
Waves.init();    
*/
