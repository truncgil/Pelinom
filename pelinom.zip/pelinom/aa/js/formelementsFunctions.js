 <!-- I_CHECK --> 
 $(document).ready(function () {

 	$('.minimal-checkbox-default').iCheck({
 		checkboxClass: 'icheckbox_minimal',
 		increaseArea: '20%'
 	});
 	$('.minimal-radio-default').iCheck({
 		radioClass: 'iradio_minimal',
 		increaseArea: '20%'
 	});


 	$('.minimal-checkbox-primary').iCheck({
 		checkboxClass: 'icheckbox_minimal-aero',
 		increaseArea: '20%'
 	});
 	$('.minimal-radio-primary').iCheck({
 		radioClass: 'iradio_minimal-aero',
 		increaseArea: '20%'
 	});


 	$('.minimal-checkbox-success').iCheck({
 		checkboxClass: 'icheckbox_minimal-green',
 		increaseArea: '20%'
 	});
 	$('.minimal-radio-success').iCheck({
 		radioClass: 'iradio_minimal-green',
 		increaseArea: '20%'
 	});



 	$('.minimal-checkbox-info').iCheck({
 		checkboxClass: 'icheckbox_minimal-purple',
 		increaseArea: '20%'
 	});
 	$('.minimal-radio-info').iCheck({
 		radioClass: 'iradio_minimal-purple',
 		increaseArea: '20%'
 	});



 	$('.minimal-checkbox-warning').iCheck({
 		checkboxClass: 'icheckbox_minimal-yellow',
 		increaseArea: '20%'
 	});
 	$('.minimal-radio-warning').iCheck({
 		radioClass: 'iradio_minimal-yellow',
 		increaseArea: '20%'
 	});



 	$('.minimal-checkbox-danger').iCheck({
 		checkboxClass: 'icheckbox_minimal-pink',
 		increaseArea: '20%'
 	});
 	$('.minimal-radio-danger').iCheck({
 		radioClass: 'iradio_minimal-pink',
 		increaseArea: '20%'
 	});



 	$('.square-checkbox-default').iCheck({
 		checkboxClass: 'icheckbox_square',
 		increaseArea: '20%'
 	});

 	$('.square-radio-default').iCheck({
 		radioClass: 'iradio_square',
 		increaseArea: '20%'
 	});


 	$('.square-checkbox-primary').iCheck({
 		checkboxClass: 'icheckbox_square-aero',
 		increaseArea: '20%'
 	});
 	$('.square-radio-primary').iCheck({
 		radioClass: 'iradio_square-aero',
 		increaseArea: '20%'
 	});

 	$('.square-checkbox-success').iCheck({
 		checkboxClass: 'icheckbox_square-green',
 		increaseArea: '20%'
 	});
 	$('.square-radio-success').iCheck({
 		radioClass: 'iradio_square-green',
 		increaseArea: '20%'
 	});


 	$('.square-checkbox-info').iCheck({
 		checkboxClass: 'icheckbox_square-purple',
 		increaseArea: '20%'
 	});
 	$('.square-radio-info').iCheck({
 		radioClass: 'iradio_square-purple',
 		increaseArea: '20%'
 	});


 	$('.square-checkbox-warning').iCheck({
 		checkboxClass: 'icheckbox_square-yellow',
 		increaseArea: '20%'
 	});
 	$('.square-radio-warning').iCheck({
 		radioClass: 'iradio_square-yellow',
 		increaseArea: '20%'
 	});



 	$('.square-checkbox-danger').iCheck({
 		checkboxClass: 'icheckbox_square-pink',
 		increaseArea: '20%'
 	});
 	$('.square-radio-danger').iCheck({
 		radioClass: 'iradio_square-pink',
 		increaseArea: '20%'
 	});



 	$('.flat-checkbox-default').iCheck({
 		checkboxClass: 'icheckbox_flat',
 		increaseArea: '20%'
 	});
 	$('.flat-radio-default').iCheck({
 		radioClass: 'iradio_flat',
 		increaseArea: '20%'
 	});


 	$('.flat-checkbox-primary').iCheck({
 		checkboxClass: 'icheckbox_flat-aero',
 		increaseArea: '20%'
 	});
 	$('.flat-radio-primary').iCheck({
 		radioClass: 'iradio_flat-aero',
 		increaseArea: '20%'
 	});


 	$('.flat-checkbox-success').iCheck({
 		checkboxClass: 'icheckbox_flat-green',
 		increaseArea: '20%'
 	});
 	$('.flat-radio-success').iCheck({
 		radioClass: 'iradio_flat-green',
 		increaseArea: '20%'
 	});


 	$('.flat-checkbox-info').iCheck({
 		checkboxClass: 'icheckbox_flat-purple',
 		increaseArea: '20%'
 	});
 	$('.flat-radio-info').iCheck({
 		radioClass: 'iradio_flat-purple',
 		increaseArea: '20%'
 	});


 	$('.flat-checkbox-warning').iCheck({
 		checkboxClass: 'icheckbox_flat-yellow',
 		increaseArea: '20%'
 	});
 	$('.flat-radio-warning').iCheck({
 		radioClass: 'iradio_flat-yellow',
 		increaseArea: '20%'
 	});


 	$('.flat-checkbox-danger').iCheck({
 		checkboxClass: 'icheckbox_flat-pink',
 		increaseArea: '20%'
 	});
 	$('.flat-radio-danger').iCheck({
 		radioClass: 'iradio_flat-pink',
 		increaseArea: '20%'
 	});
 });


 <!-- DATETIMEPICKER -->

 $(function () {
 	$('#datetimepicker').datetimepicker();
 	$('#datetimepicker1').datetimepicker();
 	$('#datetimepicker2').datetimepicker();
 	$('#datetimepicker3').datetimepicker();
 	$('#datetimepicker4').datetimepicker();
 	$('#datetimepicker5').datetimepicker();
 	$('#datetimepicker6').datetimepicker({
 		locale: 'ru'
 	});
 	$('#datetimepicker7').datetimepicker({
 		locale: 'ru'
 	});
 	$('#datetimepicker8').datetimepicker({
 		locale: 'ru'
 	});
 	$('#datetimepicker9').datetimepicker({
 		locale: 'ru'
 	});
 	$('#datetimepicker10').datetimepicker({
 		locale: 'ru'
 	});
 	$('#datetimepicker11').datetimepicker({
 		locale: 'ru'
 	});
 	$('#datetimepicker12').datetimepicker({
 		format: 'LT'
 	});
 	$('#datetimepicker13').datetimepicker({
 		format: 'LT'
 	});
 	$('#datetimepicker14').datetimepicker({
 		format: 'LT'
 	});
 	$('#datetimepicker15').datetimepicker({
 		format: 'LT'
 	});
 	$('#datetimepicker16').datetimepicker({
 		format: 'LT'
 	});
 	$('#datetimepicker17').datetimepicker({
 		format: 'LT'
 	});
 });


 $(document).ready(function () {
 	$("#range_01").ionRangeSlider();
 });

 $("#range_02").ionRangeSlider({
 	min: 100,
 	max: 1000,
 	from: 550
 });


 $("#range_03").ionRangeSlider({
 	type: "double",
 	grid: true,
 	min: 0,
 	max: 1000,
 	from: 200,
 	to: 800,
 	prefix: "$"
 });


 $("#range_04").ionRangeSlider({
 	type: "double",
 	grid: true,
 	min: -1000,
 	max: 1000,
 	from: -500,
 	to: 500
 });


 $("#range_05").ionRangeSlider({
 	type: "double",
 	grid: true,
 	from: 1,
 	to: 5,
 	values: [0, 10, 100, 1000, 10000, 100000, 1000000]
 });


 $("#range_06").ionRangeSlider({
 	grid: true,
 	from: 5,
 	values: [
        "zero", "one",
        "two", "three",
        "four", "five",
        "six", "seven",
        "eight", "nine",
        "ten"
    ]
 });


 $("#range_07").ionRangeSlider({
 	grid: true,
 	from: 3,
 	values: [
"January", "February", "March",
"April", "May", "June",
"July", "August", "September",
"October", "November", "December"
]
 });


 $("#range_8").ionRangeSlider({
 	type: "single",
 	grid: true,
 	min: -90,
 	max: 90,
 	from: 0,
 	postfix: "°"
 });


 $("#range_9").ionRangeSlider({
 	type: "double",
 	min: 100,
 	max: 200,
 	from: 145,
 	to: 155,
 	prefix: "Weight: ",
 	postfix: " million pounds",
 	decorate_both: true
 });



 $(".switch").click(function () {
 	$(this).toggleClass("on");
 })